from django.contrib import admin
from .models import SFilm

# Register your models here.
admin.site.register(SFilm)
# admin.site.register(Movie)