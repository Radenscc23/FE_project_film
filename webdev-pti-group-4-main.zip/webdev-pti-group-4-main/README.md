## ![#1589F0](https://via.placeholder.com/15/1589F0/000000?text=+) CSUI'2021 ![#f03c15](https://via.placeholder.com/15/f03c15/000000?text=+)
# FINAL PROJECT PTI - Group 4

1. Kevin
2. Maria Aurellia
3. Raden Dhaneswara TBR
4. Jeremy Alva Prathama
5. Eugenius Mario Situmorang
